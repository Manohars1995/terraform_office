provider "aws" {

  region = var.aws_region

  default_tags {

    tags = {

      Project     = var.project_name
      Environment = var.environment
      Owner       = var.owner
      ManagedBy   = "Terraform"
      Application = var.application_name

    }

  }

}